import os
import subprocess


def clone_repo(info, code_info):
    repo_name = code_info["repo"]
    branch = code_info["branch"]
    commitid = code_info["commitid"]

    repos_dir = os.path.join(info["code_path"], "repos")
    repo_dir = os.path.join(repos_dir, commitid)

    if os.path.exists(repo_dir) and os.listdir(repo_dir):
        print(f"repo already exists: {repo_dir}, skipping clone")
    else:
        os.makedirs(repo_dir, exist_ok=True)
        workspace = info["bitbucket_workspace"]
        clone_url = f"git@bitbucket.org:{workspace}/{repo_name}.git"
        subprocess.run(["git", "clone", "-b", branch, clone_url, repo_dir], check=True)
        subprocess.run(["git", "-c", "advice.detachedHead=false", "checkout", "--quiet", commitid], cwd=repo_dir, check=True)

    return repo_dir
