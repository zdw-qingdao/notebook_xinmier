import json
import os

BASE_DIR = os.environ.get("DATA_SERVER_PATH", "/mnt/data1/data_server")

COLLECTIONS_PATH = os.path.join(BASE_DIR, "collections")
DATASETS_PATH = os.path.join(BASE_DIR, "datasets")
CODE_PATH = os.path.join(BASE_DIR, "code")
MODELS_PATH = os.path.join(BASE_DIR, "models")

DATA_PLATFORM_PATH = os.path.join(os.path.dirname(__file__), "..", "..")
