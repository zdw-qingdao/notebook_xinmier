import json
import os

from fastapi import APIRouter, HTTPException

from config import CODE_PATH

router = APIRouter(prefix="/api/code", tags=["code"])


@router.get("")
def list_code_configs():
    config_dir = os.path.join(CODE_PATH, "config")
    configs = []
    if not os.path.isdir(config_dir):
        return configs
    for fname in sorted(os.listdir(config_dir)):
        if fname.endswith(".json"):
            with open(os.path.join(config_dir, fname)) as f:
                cfg = json.load(f)
            code_info = cfg.get("code_info", {})
            configs.append({
                "name": fname.replace(".json", ""),
                "filename": fname,
                "repo": code_info.get("repo", ""),
                "branch": code_info.get("branch", ""),
                "commitid": code_info.get("commitid", ""),
            })
    return configs


@router.get("/{name}")
def get_code_config(name: str):
    fpath = os.path.join(CODE_PATH, "config", name + ".json")
    if not os.path.isfile(fpath):
        raise HTTPException(404, "code config not found")
    with open(fpath) as f:
        return json.load(f)


@router.post("")
def create_code_config(data: dict):
    name = data.get("name", "").strip()
    if not name:
        raise HTTPException(400, "name required")
    fpath = os.path.join(CODE_PATH, "config", name + ".json")
    if os.path.exists(fpath):
        raise HTTPException(400, "config already exists")
    cfg = {
        "code_info": data.get("code_info", {}),
        "config": data.get("config", {}),
    }
    os.makedirs(os.path.dirname(fpath), exist_ok=True)
    with open(fpath, "w") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    return cfg


@router.put("/{name}")
def update_code_config(name: str, data: dict):
    fpath = os.path.join(CODE_PATH, "config", name + ".json")
    if not os.path.isfile(fpath):
        raise HTTPException(404, "code config not found")
    with open(fpath) as f:
        cfg = json.load(f)
    if "code_info" in data:
        cfg["code_info"] = data["code_info"]
    if "config" in data:
        cfg["config"] = data["config"]
    with open(fpath, "w") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    return cfg
