import glob
import json
import os

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse

from config import COLLECTIONS_PATH

router = APIRouter(prefix="/api/collections", tags=["collections"])


@router.get("")
def list_projects():
    projects = []
    if not os.path.exists(COLLECTIONS_PATH):
        return projects
    for name in sorted(os.listdir(COLLECTIONS_PATH)):
        info_path = os.path.join(COLLECTIONS_PATH, name, "info.json")
        if os.path.isfile(info_path):
            with open(info_path) as f:
                info = json.load(f)
            info["name"] = name
            batches = [
                d for d in os.listdir(os.path.join(COLLECTIONS_PATH, name))
                if os.path.isdir(os.path.join(COLLECTIONS_PATH, name, d)) and d != "info.json"
            ]
            info["batch_count"] = len(batches)
            projects.append(info)
    return projects


@router.post("")
def create_project(data: dict):
    name = data.get("project", "").strip()
    if not name:
        raise HTTPException(400, "project name required")
    project_dir = os.path.join(COLLECTIONS_PATH, name)
    if os.path.exists(project_dir):
        raise HTTPException(400, "project already exists")
    os.makedirs(project_dir)
    info = {
        "project": name,
        "type": data.get("type", ""),
        "device": data.get("device", ""),
        "start_date": data.get("start_date", ""),
        "end_date": data.get("end_date", ""),
        "status": data.get("status", "进行中"),
        "notes": data.get("notes", ""),
        "doc_link": data.get("doc_link", ""),
    }
    with open(os.path.join(project_dir, "info.json"), "w") as f:
        json.dump(info, f, indent=2, ensure_ascii=False)
    return info


@router.get("/{project}/batches")
def list_batches(project: str):
    project_dir = os.path.join(COLLECTIONS_PATH, project)
    if not os.path.isdir(project_dir):
        raise HTTPException(404, "project not found")
    batches = []
    for name in sorted(os.listdir(project_dir)):
        batch_dir = os.path.join(project_dir, name)
        meta_path = os.path.join(batch_dir, "meta.json")
        if os.path.isdir(batch_dir) and os.path.isfile(meta_path):
            with open(meta_path) as f:
                meta = json.load(f)
            meta["name"] = name
            ann_dir = os.path.join(batch_dir, "annotations")
            meta["annotation_count"] = len(os.listdir(ann_dir)) if os.path.isdir(ann_dir) else 0
            batches.append(meta)
    return batches


@router.get("/{project}/{batch}")
def get_batch_detail(project: str, batch: str):
    batch_dir = os.path.join(COLLECTIONS_PATH, project, batch)
    meta_path = os.path.join(batch_dir, "meta.json")
    if not os.path.isfile(meta_path):
        raise HTTPException(404, "batch not found")
    with open(meta_path) as f:
        meta = json.load(f)
    meta["name"] = batch
    meta["project"] = project

    images_dir = os.path.join(batch_dir, "images")
    image_files = []
    if os.path.isdir(images_dir):
        for sub in sorted(os.listdir(images_dir)):
            sub_dir = os.path.join(images_dir, sub)
            if os.path.isdir(sub_dir):
                for img in sorted(os.listdir(sub_dir)):
                    if img.lower().endswith((".png", ".jpg", ".jpeg")):
                        image_files.append(f"{sub}/{img}")
            elif sub.lower().endswith((".png", ".jpg", ".jpeg")):
                image_files.append(sub)
    meta["images"] = image_files
    meta["image_count"] = len(image_files)

    video_dir = os.path.join(batch_dir, "video")
    meta["videos"] = []
    if os.path.isdir(video_dir):
        meta["videos"] = sorted([f for f in os.listdir(video_dir) if f.endswith(".mp4")])

    ann_dir = os.path.join(batch_dir, "annotations")
    annotations = []
    if os.path.isdir(ann_dir):
        for ann_name in sorted(os.listdir(ann_dir)):
            ann_meta_path = os.path.join(ann_dir, ann_name, "meta.json")
            if os.path.isfile(ann_meta_path):
                with open(ann_meta_path) as f:
                    ann_meta = json.load(f)
                ann_meta["name"] = ann_name
                annotations.append(ann_meta)
    meta["annotations"] = annotations
    return meta


@router.get("/{project}/{batch}/images/{image_path:path}")
def get_image(project: str, batch: str, image_path: str):
    file_path = os.path.join(COLLECTIONS_PATH, project, batch, "images", image_path)
    if not os.path.isfile(file_path):
        raise HTTPException(404, "image not found")
    return FileResponse(file_path)


@router.get("/{project}/{batch}/annotations/{annotation}/labels/{label_path:path}")
def get_label(project: str, batch: str, annotation: str, label_path: str):
    file_path = os.path.join(COLLECTIONS_PATH, project, batch, "annotations", annotation, "labels", label_path)
    if not os.path.isfile(file_path):
        return {"boxes": []}
    with open(file_path) as f:
        lines = f.read().strip().splitlines()
    boxes = []
    for line in lines:
        parts = line.split()
        if len(parts) >= 5:
            boxes.append({
                "cls": int(parts[0]),
                "x": float(parts[1]),
                "y": float(parts[2]),
                "w": float(parts[3]),
                "h": float(parts[4]),
                "conf": float(parts[5]) if len(parts) > 5 else None,
            })
    return {"boxes": boxes}
