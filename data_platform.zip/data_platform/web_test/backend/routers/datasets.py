import json
import os

from fastapi import APIRouter, HTTPException

from config import DATASETS_PATH

router = APIRouter(prefix="/api/datasets", tags=["datasets"])


@router.get("")
def list_datasets():
    datasets = []
    if not os.path.exists(DATASETS_PATH):
        return datasets
    for fname in sorted(os.listdir(DATASETS_PATH)):
        if fname.endswith(".json"):
            with open(os.path.join(DATASETS_PATH, fname)) as f:
                ds = json.load(f)
            train_count = sum(e["index"][1] - e["index"][0] for e in ds.get("splits", {}).get("train", []))
            val_count = sum(e["index"][1] - e["index"][0] for e in ds.get("splits", {}).get("val", []))
            datasets.append({
                "name": ds.get("name", fname.replace(".json", "")),
                "filename": fname,
                "created_at": ds.get("created_at", ""),
                "train_count": train_count,
                "val_count": val_count,
            })
    return datasets


@router.get("/{name}")
def get_dataset(name: str):
    fpath = os.path.join(DATASETS_PATH, name + ".json")
    if not os.path.isfile(fpath):
        raise HTTPException(404, "dataset not found")
    with open(fpath) as f:
        return json.load(f)


@router.post("")
def create_dataset(data: dict):
    name = data.get("name", "").strip()
    if not name:
        raise HTTPException(400, "name required")
    fpath = os.path.join(DATASETS_PATH, name + ".json")
    if os.path.exists(fpath):
        raise HTTPException(400, "dataset already exists")
    from datetime import date
    dataset = {
        "name": name,
        "created_at": str(date.today()),
        "splits": data.get("splits", {"train": [], "val": []}),
    }
    os.makedirs(DATASETS_PATH, exist_ok=True)
    with open(fpath, "w") as f:
        json.dump(dataset, f, indent=2, ensure_ascii=False)
    return dataset


@router.put("/{name}")
def update_dataset(name: str, data: dict):
    fpath = os.path.join(DATASETS_PATH, name + ".json")
    if not os.path.isfile(fpath):
        raise HTTPException(404, "dataset not found")
    with open(fpath) as f:
        dataset = json.load(f)
    dataset["splits"] = data.get("splits", dataset["splits"])
    with open(fpath, "w") as f:
        json.dump(dataset, f, indent=2, ensure_ascii=False)
    return dataset


@router.delete("/{name}")
def delete_dataset(name: str):
    fpath = os.path.join(DATASETS_PATH, name + ".json")
    if not os.path.isfile(fpath):
        raise HTTPException(404, "dataset not found")
    os.remove(fpath)
    return {"status": "deleted"}
