import json
import os
import subprocess
import sys
import threading

from fastapi import APIRouter, HTTPException

from config import MODELS_PATH, CODE_PATH, DATASETS_PATH, DATA_PLATFORM_PATH

router = APIRouter(prefix="/api/training", tags=["training"])

_running_tasks = {}


@router.get("/tasks")
def list_training_tasks():
    tasks = []
    if not os.path.isdir(MODELS_PATH):
        return tasks
    for name in sorted(os.listdir(MODELS_PATH)):
        model_dir = os.path.join(MODELS_PATH, name)
        config_dir = os.path.join(model_dir, "config")
        train_cfg_path = os.path.join(config_dir, "model_train.json")
        if not os.path.isfile(train_cfg_path):
            continue
        with open(train_cfg_path) as f:
            train_cfg = json.load(f)
        has_weights = os.path.isfile(os.path.join(model_dir, "weights", "best.pt"))
        status = "已完成" if has_weights else "训练中" if name in _running_tasks else "未开始"
        tasks.append({
            "name": name,
            "dataset_config": train_cfg.get("dataset_config", ""),
            "code_config": train_cfg.get("code_config", ""),
            "pretrained_model": train_cfg.get("pretrained_model", ""),
            "status": status,
        })
    return tasks


@router.post("/start")
def start_training(data: dict):
    model_name = data.get("model_name", "").strip()
    if not model_name:
        raise HTTPException(400, "model_name required")
    if model_name in _running_tasks:
        raise HTTPException(400, "training already running")

    train_config = {
        "code_config": data.get("code_config", ""),
        "dataset_config": data.get("dataset_config", ""),
        "pretrained_model": data.get("pretrained_model", ""),
        "model_name": model_name,
        "inference_train_set": False,
        "inference_val_set": data.get("inference_val_set", True),
        "batch": data.get("batch", 16),
        "device": data.get("device", [0]),
    }

    model_dir = os.path.join(MODELS_PATH, model_name)
    config_dir = os.path.join(model_dir, "config")
    os.makedirs(config_dir, exist_ok=True)
    config_path = os.path.join(config_dir, "model_train.json")
    with open(config_path, "w") as f:
        json.dump(train_config, f, indent=2, ensure_ascii=False)

    def run_task():
        try:
            cmd = [
                sys.executable,
                os.path.join(DATA_PLATFORM_PATH, "model_run.py"),
                "-c", config_path,
            ]
            subprocess.run(cmd, cwd=DATA_PLATFORM_PATH, check=True)
        finally:
            _running_tasks.pop(model_name, None)

    t = threading.Thread(target=run_task, daemon=True)
    t.start()
    _running_tasks[model_name] = t

    return {"status": "started", "model_name": model_name}


@router.get("/status/{model_name}")
def get_training_status(model_name: str):
    model_dir = os.path.join(MODELS_PATH, model_name)
    if not os.path.isdir(model_dir):
        raise HTTPException(404, "model not found")
    has_weights = os.path.isfile(os.path.join(model_dir, "weights", "best.pt"))
    return {
        "name": model_name,
        "running": model_name in _running_tasks,
        "completed": has_weights,
        "status": "已完成" if has_weights else "训练中" if model_name in _running_tasks else "未开始",
    }
