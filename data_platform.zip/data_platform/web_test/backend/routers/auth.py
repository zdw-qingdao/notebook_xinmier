import hashlib
import json
import os
import time

import jwt
from fastapi import APIRouter, Depends, HTTPException, Request

router = APIRouter(prefix="/api/auth", tags=["auth"])

USERS_FILE = os.path.join(os.path.dirname(__file__), "..", "users.json")
JWT_SECRET = "foundry_secret_key_2026"
JWT_EXPIRE = 86400 * 7


def _load_users():
    with open(USERS_FILE) as f:
        return json.load(f)


def _save_users(data):
    with open(USERS_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def _hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def _create_token(username: str, role: str) -> str:
    payload = {
        "username": username,
        "role": role,
        "exp": int(time.time()) + JWT_EXPIRE,
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")


def get_current_user(request: Request) -> dict:
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    if not token:
        raise HTTPException(401, "未登录")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "登录已过期")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "无效的登录凭证")
    return payload


def require_admin(user: dict = Depends(get_current_user)):
    if user.get("role") != "admin":
        raise HTTPException(403, "需要管理员权限")
    return user


@router.post("/login")
def login(data: dict):
    username = data.get("username", "").strip()
    password = data.get("password", "")
    if not username or not password:
        raise HTTPException(400, "用户名和密码不能为空")

    users_data = _load_users()
    for user in users_data["users"]:
        if user["username"] == username and user["password_hash"] == _hash_password(password):
            token = _create_token(username, user["role"])
            return {"token": token, "username": username, "role": user["role"]}

    raise HTTPException(401, "用户名或密码错误")


@router.get("/me")
def get_me(user: dict = Depends(get_current_user)):
    return {"username": user["username"], "role": user["role"]}


@router.get("/users")
def list_users(user: dict = Depends(require_admin)):
    users_data = _load_users()
    return [{"username": u["username"], "role": u["role"]} for u in users_data["users"]]


@router.post("/users")
def create_user(data: dict, user: dict = Depends(require_admin)):
    username = data.get("username", "").strip()
    password = data.get("password", "")
    role = data.get("role", "user")
    if not username or not password:
        raise HTTPException(400, "用户名和密码不能为空")
    if role not in ("admin", "user"):
        raise HTTPException(400, "角色必须是 admin 或 user")

    users_data = _load_users()
    for u in users_data["users"]:
        if u["username"] == username:
            raise HTTPException(400, "用户名已存在")

    users_data["users"].append({
        "username": username,
        "password_hash": _hash_password(password),
        "role": role,
    })
    _save_users(users_data)
    return {"username": username, "role": role}


@router.delete("/users/{username}")
def delete_user(username: str, user: dict = Depends(require_admin)):
    if username == user["username"]:
        raise HTTPException(400, "不能删除自己")
    users_data = _load_users()
    users_data["users"] = [u for u in users_data["users"] if u["username"] != username]
    _save_users(users_data)
    return {"status": "deleted"}


@router.put("/users/{username}/password")
def change_password(username: str, data: dict, user: dict = Depends(get_current_user)):
    if user["role"] != "admin" and user["username"] != username:
        raise HTTPException(403, "无权修改")
    new_password = data.get("password", "")
    if not new_password:
        raise HTTPException(400, "密码不能为空")

    users_data = _load_users()
    for u in users_data["users"]:
        if u["username"] == username:
            u["password_hash"] = _hash_password(new_password)
            _save_users(users_data)
            return {"status": "ok"}
    raise HTTPException(404, "用户不存在")
