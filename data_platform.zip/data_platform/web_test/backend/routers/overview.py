import json
import os

from fastapi import APIRouter

from config import COLLECTIONS_PATH, DATASETS_PATH, MODELS_PATH

router = APIRouter(prefix="/api/overview", tags=["overview"])


@router.get("")
def get_overview():
    project_count = 0
    active_count = 0
    total_images = 0
    if os.path.isdir(COLLECTIONS_PATH):
        for name in os.listdir(COLLECTIONS_PATH):
            info_path = os.path.join(COLLECTIONS_PATH, name, "info.json")
            if os.path.isfile(info_path):
                project_count += 1
                with open(info_path) as f:
                    info = json.load(f)
                if info.get("status") == "进行中":
                    active_count += 1
                project_dir = os.path.join(COLLECTIONS_PATH, name)
                for batch in os.listdir(project_dir):
                    meta_path = os.path.join(project_dir, batch, "meta.json")
                    if os.path.isfile(meta_path):
                        with open(meta_path) as f:
                            meta = json.load(f)
                        total_images += meta.get("count", 0)

    model_count = 0
    if os.path.isdir(MODELS_PATH):
        model_count = sum(1 for d in os.listdir(MODELS_PATH) if os.path.isdir(os.path.join(MODELS_PATH, d)))

    dataset_count = 0
    if os.path.isdir(DATASETS_PATH):
        dataset_count = sum(1 for f in os.listdir(DATASETS_PATH) if f.endswith(".json"))

    return {
        "project_count": project_count,
        "active_count": active_count,
        "completed_count": project_count - active_count,
        "total_images": total_images,
        "model_count": model_count,
        "dataset_count": dataset_count,
    }
