import json
import os
import re

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse


def load_json_lenient(path):
    with open(path) as f:
        text = f.read()
    text = re.sub(r',\s*([}\]])', r'\1', text)
    return json.loads(text)

from config import MODELS_PATH

router = APIRouter(prefix="/api/models", tags=["models"])


@router.get("")
def list_models():
    models = []
    if not os.path.isdir(MODELS_PATH):
        return models
    for name in sorted(os.listdir(MODELS_PATH)):
        model_dir = os.path.join(MODELS_PATH, name)
        if not os.path.isdir(model_dir):
            continue
        meta_path = os.path.join(model_dir, "meta.json")
        meta = {}
        if os.path.isfile(meta_path):
            meta = load_json_lenient(meta_path)
        meta["name"] = name
        meta["has_weights"] = os.path.isfile(os.path.join(model_dir, "weights", "best.pt")) or \
                              os.path.isfile(os.path.join(model_dir, "weights", "last.pt"))
        config_dir = os.path.join(model_dir, "config")
        if os.path.isdir(config_dir):
            train_cfg_path = os.path.join(config_dir, "model_train.json")
            if os.path.isfile(train_cfg_path):
                train_cfg = load_json_lenient(train_cfg_path)
                meta["dataset_config"] = train_cfg.get("dataset_config", "")
                meta["code_config"] = train_cfg.get("code_config", meta.get("code_config", ""))
        models.append(meta)
    return models


@router.get("/{name}")
def get_model(name: str):
    model_dir = os.path.join(MODELS_PATH, name)
    if not os.path.isdir(model_dir):
        raise HTTPException(404, "model not found")
    meta_path = os.path.join(model_dir, "meta.json")
    meta = {}
    if os.path.isfile(meta_path):
        try:
            meta = load_json_lenient(meta_path)
        except Exception:
            meta = {}
    meta["name"] = name

    weights_dir = os.path.join(model_dir, "weights")
    meta["weights"] = sorted(os.listdir(weights_dir)) if os.path.isdir(weights_dir) else []

    config_dir = os.path.join(model_dir, "config")
    meta["config_files"] = sorted(os.listdir(config_dir)) if os.path.isdir(config_dir) else []

    train_img_dir = os.path.join(model_dir, "train_img")
    meta["train_images"] = sorted(os.listdir(train_img_dir)) if os.path.isdir(train_img_dir) else []

    config_dir = os.path.join(model_dir, "config")
    if os.path.isdir(config_dir):
        train_cfg_path = os.path.join(config_dir, "model_train.json")
        if os.path.isfile(train_cfg_path):
                meta["train_config"] = load_json_lenient(train_cfg_path)
        args_path = os.path.join(config_dir, "args.yaml")
        if os.path.isfile(args_path):
            with open(args_path) as f:
                meta["args_yaml"] = f.read()

    return meta


@router.get("/{name}/config/{filename}")
def get_model_config_file(name: str, filename: str):
    fpath = os.path.join(MODELS_PATH, name, "config", filename)
    if not os.path.isfile(fpath):
        raise HTTPException(404, "file not found")
    if filename.endswith(".json"):
        with open(fpath) as f:
            return json.load(f)
    with open(fpath) as f:
        return {"content": f.read()}


@router.get("/{name}/train_img/{filename}")
def get_train_image(name: str, filename: str):
    fpath = os.path.join(MODELS_PATH, name, "train_img", filename)
    if not os.path.isfile(fpath):
        raise HTTPException(404, "image not found")
    return FileResponse(fpath)


@router.get("/{name}/weights/{filename}")
def download_weight(name: str, filename: str):
    fpath = os.path.join(MODELS_PATH, name, "weights", filename)
    if not os.path.isfile(fpath):
        raise HTTPException(404, "weight file not found")
    return FileResponse(fpath, filename=filename)
