import os
import signal
import subprocess
import sys

import httpx
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse as StarletteJSONResponse

from routers import auth, collections, datasets, code, models, training, overview

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

PUBLIC_PATHS = {"/api/auth/login", "/api/health"}


class AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        is_public = path in PUBLIC_PATHS or "/images/" in path or "/train_img/" in path
        if path.startswith("/api/") and not is_public:
            token = request.headers.get("Authorization", "").replace("Bearer ", "")
            if not token:
                return StarletteJSONResponse({"detail": "未登录"}, status_code=401)
            import jwt
            try:
                jwt.decode(token, auth.JWT_SECRET, algorithms=["HS256"])
            except Exception:
                return StarletteJSONResponse({"detail": "登录已过期"}, status_code=401)
        return await call_next(request)


app.add_middleware(AuthMiddleware)

app.include_router(auth.router)
app.include_router(overview.router)
app.include_router(collections.router)
app.include_router(datasets.router)
app.include_router(code.router)
app.include_router(models.router)
app.include_router(training.router)

FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "..", "frontend")
DIST_DIR = os.path.join(FRONTEND_DIR, "dist")
VITE_DEV_URL = "http://localhost:5173"

vite_process = None


@app.get("/api/health")
def health():
    return {"status": "ok"}


dev_mode = not os.path.exists(DIST_DIR)

if not dev_mode:
    app.mount("/", StaticFiles(directory=DIST_DIR, html=True), name="static")
else:

    @app.api_route("/{path:path}", methods=["GET", "HEAD"])
    async def proxy_to_vite(path: str, request: Request):
        url = f"{VITE_DEV_URL}/{path}"
        headers = dict(request.headers)
        headers.pop("host", None)
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, headers=headers)
            return Response(
                content=resp.content,
                status_code=resp.status_code,
                headers=dict(resp.headers),
            )


def start_vite():
    global vite_process
    vite_process = subprocess.Popen(
        ["npx", "vite", "--host", "0.0.0.0"],
        cwd=FRONTEND_DIR,
        stdout=sys.stdout,
        stderr=sys.stderr,
    )


def stop_vite(*_):
    global vite_process
    if vite_process:
        vite_process.terminate()
        vite_process.wait()
        vite_process = None


if __name__ == "__main__":
    if dev_mode:
        start_vite()
        signal.signal(signal.SIGINT, lambda *_: (stop_vite(), sys.exit(0)))
        signal.signal(signal.SIGTERM, lambda *_: (stop_vite(), sys.exit(0)))

    try:
        uvicorn.run(app, host="0.0.0.0", port=10077)
    finally:
        stop_vite()
