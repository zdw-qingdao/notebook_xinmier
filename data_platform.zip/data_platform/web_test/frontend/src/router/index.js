import { createRouter, createWebHistory } from 'vue-router'
import { isLoggedIn } from '../auth'
import HomeView from '../views/HomeView.vue'
import LoginView from '../views/LoginView.vue'

const routes = [
  { path: '/login', name: 'login', component: LoginView, meta: { public: true } },
  { path: '/', name: 'home', component: HomeView },
  { path: '/collections', name: 'collections', component: () => import('../views/collections/ProjectList.vue') },
  { path: '/collections/:project', name: 'batches', component: () => import('../views/collections/BatchList.vue') },
  { path: '/collections/:project/:batch', name: 'batch-detail', component: () => import('../views/collections/BatchDetail.vue') },
  { path: '/collections/:project/:batch/annotations', name: 'annotation-viewer', component: () => import('../views/collections/AnnotationViewer.vue') },
  { path: '/datasets', name: 'datasets', component: () => import('../views/datasets/DatasetList.vue') },
  { path: '/datasets/new', name: 'dataset-new', component: () => import('../views/datasets/DatasetForm.vue') },
  { path: '/datasets/:name/edit', name: 'dataset-edit', component: () => import('../views/datasets/DatasetForm.vue') },
  { path: '/code', name: 'code', component: () => import('../views/code/CodeList.vue') },
  { path: '/code/new', name: 'code-new', component: () => import('../views/code/CodeForm.vue') },
  { path: '/code/:name/edit', name: 'code-edit', component: () => import('../views/code/CodeForm.vue') },
  { path: '/models', name: 'models', component: () => import('../views/models/ModelList.vue') },
  { path: '/models/:name', name: 'model-detail', component: () => import('../views/models/ModelDetail.vue') },
  { path: '/training', name: 'training', component: () => import('../views/training/TrainingList.vue') },
  { path: '/training/new', name: 'training-new', component: () => import('../views/training/TrainingForm.vue') },
  { path: '/evaluation', name: 'evaluation', component: () => import('../views/evaluation/EvaluationView.vue') },
  { path: '/admin/users', name: 'user-management', component: () => import('../views/admin/UserManagement.vue') },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

router.beforeEach((to) => {
  if (!to.meta.public && !isLoggedIn.value) {
    return { name: 'login' }
  }
})

export default router
