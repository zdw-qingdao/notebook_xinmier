import { ref, computed } from 'vue'

const token = ref(localStorage.getItem('token') || '')
const username = ref(localStorage.getItem('username') || '')
const role = ref(localStorage.getItem('role') || '')

export const isLoggedIn = computed(() => !!token.value)
export const currentUser = computed(() => ({ username: username.value, role: role.value }))
export const isAdmin = computed(() => role.value === 'admin')

export function setAuth(data) {
  token.value = data.token
  username.value = data.username
  role.value = data.role
  localStorage.setItem('token', data.token)
  localStorage.setItem('username', data.username)
  localStorage.setItem('role', data.role)
}

export function clearAuth() {
  token.value = ''
  username.value = ''
  role.value = ''
  localStorage.removeItem('token')
  localStorage.removeItem('username')
  localStorage.removeItem('role')
}

export function getToken() {
  return token.value
}

export async function apiFetch(url, options = {}) {
  const headers = { ...options.headers }
  if (token.value) {
    headers['Authorization'] = `Bearer ${token.value}`
  }
  if (options.body && typeof options.body === 'string') {
    headers['Content-Type'] = headers['Content-Type'] || 'application/json'
  }
  const res = await fetch(url, { ...options, headers })
  if (res.status === 401) {
    clearAuth()
    window.location.href = '/login'
    throw new Error('未登录')
  }
  return res
}
