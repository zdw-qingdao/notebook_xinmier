<template>
  <router-view v-if="$route.name === 'login'" />

  <el-container v-else class="app-container">
    <el-header class="app-header">
      <div class="header-left">
        <span class="logo" @click="$router.push('/')" style="cursor: pointer">Foundry</span>
      </div>
      <div class="header-right">
        <el-dropdown @command="handleCommand">
          <span class="user-dropdown">
            <el-icon><User /></el-icon>
            <span>{{ currentUser.username }}</span>
            <el-icon><ArrowDown /></el-icon>
          </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item v-if="isAdmin" command="users">用户管理</el-dropdown-item>
              <el-dropdown-item command="logout" divided>退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </el-header>

    <el-container>
      <el-aside :width="isCollapsed ? '64px' : '200px'" class="app-aside">
        <div class="collapse-btn" @click="isCollapsed = !isCollapsed">
          <el-icon><Fold v-if="!isCollapsed" /><Expand v-else /></el-icon>
        </div>
        <el-menu
          :default-active="activeMenu"
          :collapse="isCollapsed"
          router
          class="side-menu"
        >
          <el-menu-item index="/collections">
            <el-icon><FolderOpened /></el-icon>
            <span>数据采集</span>
          </el-menu-item>
          <el-menu-item index="/datasets">
            <el-icon><Files /></el-icon>
            <span>数据集</span>
          </el-menu-item>
          <el-menu-item index="/code">
            <el-icon><Document /></el-icon>
            <span>代码</span>
          </el-menu-item>
          <el-menu-item index="/models">
            <el-icon><Box /></el-icon>
            <span>模型结果</span>
          </el-menu-item>
          <el-menu-item index="/training">
            <el-icon><VideoPlay /></el-icon>
            <span>训练</span>
          </el-menu-item>
          <el-menu-item index="/evaluation">
            <el-icon><DataAnalysis /></el-icon>
            <span>评测</span>
          </el-menu-item>
        </el-menu>
      </el-aside>

      <el-main class="app-main">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { currentUser, isAdmin, clearAuth } from './auth'

const route = useRoute()
const router = useRouter()
const isCollapsed = ref(false)
const activeMenu = computed(() => route.path)

function handleCommand(cmd) {
  if (cmd === 'logout') {
    clearAuth()
    router.push('/login')
  } else if (cmd === 'users') {
    router.push('/admin/users')
  }
}
</script>

<style>
html, body, #app {
  margin: 0;
  padding: 0;
  height: 100%;
}

.app-container {
  height: 100vh;
}

.app-header {
  background: #2d3a4b;
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  height: 50px;
  line-height: 50px;
}

.header-left .logo {
  font-size: 20px;
  font-weight: bold;
  letter-spacing: 1px;
}

.header-right {
  display: flex;
  align-items: center;
}

.user-dropdown {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  color: #fff;
  cursor: pointer;
}

.app-aside {
  background: #304156;
  transition: width 0.3s;
  overflow: hidden;
}

.collapse-btn {
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: #bfcbd9;
}

.collapse-btn:hover {
  color: #fff;
}

.side-menu {
  border-right: none;
  background: #304156;
}

.side-menu .el-menu-item {
  color: #bfcbd9;
}

.side-menu .el-menu-item:hover {
  background: #263445;
}

.side-menu .el-menu-item.is-active {
  color: #409eff;
  background: #263445;
}

.app-main {
  background: #f0f2f5;
  padding: 20px;
  overflow-y: auto;
}
</style>
