<template>
  <div>
    <div class="page-header">
      <h2>数据集</h2>
      <el-button type="primary" @click="$router.push('/datasets/new')">+ 新建数据集</el-button>
    </div>
    <el-table :data="datasets" stripe>
      <el-table-column prop="name" label="名称" />
      <el-table-column prop="train_count" label="训练集" />
      <el-table-column prop="val_count" label="验证集" />
      <el-table-column prop="created_at" label="创建时间" />
      <el-table-column label="操作" width="180">
        <template #default="{ row }">
          <el-button size="small" @click="$router.push(`/datasets/${row.name}/edit`)">编辑</el-button>
          <el-button size="small" type="danger" @click="deleteDataset(row.name)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const datasets = ref([])

async function load() {
  const res = await apiFetch('/api/datasets')
  datasets.value = await res.json()
}

async function deleteDataset(name) {
  await ElMessageBox.confirm(`确认删除数据集 ${name}?`, '确认')
  const res = await apiFetch(`/api/datasets/${name}`, { method: 'DELETE' })
  if (res.ok) {
    ElMessage.success('删除成功')
    load()
  }
}

onMounted(load)
</script>

<style scoped>
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
</style>
