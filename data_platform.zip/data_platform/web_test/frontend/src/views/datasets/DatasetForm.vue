<template>
  <div>
    <el-breadcrumb separator=">">
      <el-breadcrumb-item :to="{ path: '/datasets' }">数据集</el-breadcrumb-item>
      <el-breadcrumb-item>{{ isEdit ? '编辑' : '新建' }}数据集</el-breadcrumb-item>
    </el-breadcrumb>

    <h2 style="margin: 16px 0">{{ isEdit ? '编辑' : '新建' }}数据集</h2>

    <el-form :model="form" label-width="80px" style="max-width: 800px">
      <el-form-item label="名称">
        <el-input v-model="form.name" :disabled="isEdit" />
      </el-form-item>

      <div v-for="split in ['train', 'val']" :key="split" style="margin-bottom: 24px">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px">
          <strong>{{ split === 'train' ? '训练集' : '验证集' }}</strong>
          <el-button size="small" @click="addEntry(split)">+ 添加来源</el-button>
        </div>
        <el-table :data="form.splits[split]" border size="small">
          <el-table-column label="来源采集" min-width="200">
            <template #default="{ row }">
              <el-cascader
                v-model="row._collection"
                :options="collectionOptions"
                @change="val => onCollectionChange(row, val)"
                placeholder="选择项目/批次"
                size="small"
                style="width: 100%"
              />
            </template>
          </el-table-column>
          <el-table-column label="标注版本" min-width="200">
            <template #default="{ row }">
              <el-select v-model="row.annotation" placeholder="选择标注" size="small" style="width: 100%">
                <el-option
                  v-for="ann in (annotationCache[row.collection] || [])"
                  :key="ann"
                  :value="ann"
                  :label="ann"
                />
              </el-select>
            </template>
          </el-table-column>
          <el-table-column label="范围" width="180">
            <template #default="{ row }">
              <div style="display: flex; gap: 4px">
                <el-input-number v-model="row.index[0]" :min="0" size="small" controls-position="right" style="width: 80px" />
                <span style="line-height: 32px">-</span>
                <el-input-number v-model="row.index[1]" :min="0" size="small" controls-position="right" style="width: 80px" />
              </div>
            </template>
          </el-table-column>
          <el-table-column label="" width="60">
            <template #default="{ $index }">
              <el-button size="small" type="danger" text @click="form.splits[split].splice($index, 1)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <el-form-item>
        <el-button @click="$router.push('/datasets')">取消</el-button>
        <el-button type="primary" @click="save">保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { ref, reactive, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'

const route = useRoute()
const router = useRouter()
const isEdit = !!route.params.name
const collectionOptions = ref([])
const annotationCache = reactive({})

const form = reactive({
  name: route.params.name || '',
  splits: { train: [], val: [] },
})

function addEntry(split) {
  form.splits[split].push({ collection: '', annotation: '', index: [0, 0], _collection: [] })
}

async function loadCollections() {
  const res = await apiFetch('/api/collections')
  const projects = await res.json()
  const options = []
  for (const p of projects) {
    const batchRes = await apiFetch(`/api/collections/${p.name || p.project}/batches`)
    const batches = await batchRes.json()
    options.push({
      value: p.name || p.project,
      label: p.name || p.project,
      children: batches.map(b => ({ value: b.name, label: b.name })),
    })
  }
  collectionOptions.value = options
}

async function onCollectionChange(row, val) {
  if (val && val.length === 2) {
    row.collection = `${val[0]}/${val[1]}`
    if (!annotationCache[row.collection]) {
      const res = await apiFetch(`/api/collections/${val[0]}/${val[1]}`)
      const detail = await res.json()
      annotationCache[row.collection] = (detail.annotations || []).map(a => a.name)
    }
  }
}

async function save() {
  const payload = {
    name: form.name,
    splits: {
      train: form.splits.train.map(e => ({ collection: e.collection, annotation: e.annotation, index: e.index })),
      val: form.splits.val.map(e => ({ collection: e.collection, annotation: e.annotation, index: e.index })),
    },
  }
  const url = isEdit ? `/api/datasets/${form.name}` : '/api/datasets'
  const method = isEdit ? 'PUT' : 'POST'
  const res = await apiFetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (res.ok) {
    ElMessage.success('保存成功')
    router.push('/datasets')
  } else {
    const err = await res.json()
    ElMessage.error(err.detail || '保存失败')
  }
}

onMounted(async () => {
  await loadCollections()
  if (isEdit) {
    const res = await apiFetch(`/api/datasets/${route.params.name}`)
    const data = await res.json()
    form.name = data.name
    for (const split of ['train', 'val']) {
      form.splits[split] = (data.splits[split] || []).map(e => {
        const parts = e.collection.split('/')
        return { ...e, _collection: parts }
      })
      for (const e of form.splits[split]) {
        onCollectionChange(e, e._collection)
      }
    }
  }
})
</script>
