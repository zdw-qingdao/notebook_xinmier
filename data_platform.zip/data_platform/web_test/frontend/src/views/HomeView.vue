<template>
  <div>
    <h2>概览</h2>
    <el-row :gutter="20">
      <el-col :span="6" v-for="card in cards" :key="card.label">
        <el-card shadow="hover">
          <template #header>{{ card.label }}</template>
          <div class="stat-value">{{ card.value }}</div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { apiFetch } from '../auth'
import { ref, onMounted } from 'vue'

const cards = ref([])

onMounted(async () => {
  const res = await apiFetch('/api/overview')
  const data = await res.json()
  cards.value = [
    { label: '已完成项目', value: data.completed_count },
    { label: '进行中项目', value: data.active_count },
    { label: '数据总量', value: data.total_images.toLocaleString() },
    { label: '模型数量', value: data.model_count },
  ]
})
</script>

<style scoped>
.stat-value {
  font-size: 32px;
  font-weight: bold;
  text-align: center;
  color: #409eff;
}
</style>
