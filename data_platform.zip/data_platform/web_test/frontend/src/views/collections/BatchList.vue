<template>
  <div>
    <el-breadcrumb separator=">">
      <el-breadcrumb-item :to="{ path: '/collections' }">数据采集</el-breadcrumb-item>
      <el-breadcrumb-item>{{ project }}</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="page-header">
      <h2>{{ project }} - 采集批次</h2>
    </div>
    <el-table :data="batches" stripe @row-click="goToDetail" style="cursor: pointer">
      <el-table-column prop="name" label="批次名" />
      <el-table-column prop="count" label="图片数" />
      <el-table-column prop="annotation_count" label="标注版本数" />
      <el-table-column prop="date" label="采集时间" />
      <el-table-column prop="resolution" label="分辨率" />
    </el-table>
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const route = useRoute()
const router = useRouter()
const project = route.params.project
const batches = ref([])

async function load() {
  const res = await apiFetch(`/api/collections/${project}/batches`)
  batches.value = await res.json()
}

function goToDetail(row) {
  router.push(`/collections/${project}/${row.name}`)
}

onMounted(load)
</script>

<style scoped>
.page-header { display: flex; justify-content: space-between; align-items: center; margin: 16px 0; }
</style>
