<template>
  <div>
    <el-breadcrumb separator=">">
      <el-breadcrumb-item :to="{ path: '/collections' }">数据采集</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: `/collections/${project}` }">{{ project }}</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: `/collections/${project}/${batch}` }">{{ batch }}</el-breadcrumb-item>
      <el-breadcrumb-item>标注查看</el-breadcrumb-item>
    </el-breadcrumb>

    <h2 style="margin: 16px 0">标注查看</h2>

    <el-card style="margin-bottom: 16px">
      <template #header>标注版本（可多选）</template>
      <el-checkbox-group v-model="selectedAnnotations">
        <el-checkbox v-for="ann in annotations" :key="ann.name" :value="ann.name">
          <span :style="{ color: getColor(ann.name) }">■</span>
          {{ ann.name }} - {{ ann.type }} - {{ ann.method }}
        </el-checkbox>
      </el-checkbox-group>
    </el-card>

    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px">
      <div>
        每页显示:
        <el-select v-model="pageSize" style="width: 80px" size="small">
          <el-option :value="4" label="4" />
          <el-option :value="8" label="8" />
          <el-option :value="16" label="16" />
          <el-option :value="32" label="32" />
        </el-select>
      </div>
      <el-pagination
        layout="prev, pager, next"
        :total="images.length"
        :page-size="pageSize"
        v-model:current-page="currentPage"
      />
    </div>

    <div class="image-grid">
      <div v-for="img in pagedImages" :key="img" class="image-card">
        <div class="canvas-container">
          <canvas :ref="el => canvasRefs[img] = el" @click="openPreview(img)" />
        </div>
        <div class="image-label">{{ img.split('/').pop() }}</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { ref, computed, watch, onMounted, nextTick } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const project = route.params.project
const batch = route.params.batch

const annotations = ref([])
const selectedAnnotations = ref([])
const images = ref([])
const currentPage = ref(1)
const pageSize = ref(8)
const canvasRefs = ref({})

const COLORS = ['#409eff', '#67c23a', '#e6a23c', '#f56c6c', '#909399', '#b37feb']
function getColor(name) {
  const idx = annotations.value.findIndex(a => a.name === name)
  return COLORS[idx % COLORS.length]
}

const pagedImages = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value
  return images.value.slice(start, start + pageSize.value)
})

async function loadDetail() {
  const res = await apiFetch(`/api/collections/${project}/${batch}`)
  const data = await res.json()
  images.value = data.images || []
  annotations.value = data.annotations || []
  if (annotations.value.length) {
    selectedAnnotations.value = [annotations.value[0].name]
  }
}

async function drawImage(imgPath) {
  const canvas = canvasRefs.value[imgPath]
  if (!canvas) return
  const ctx = canvas.getContext('2d')
  const img = new Image()
  img.crossOrigin = 'anonymous'
  img.src = `/api/collections/${project}/${batch}/images/${imgPath}`
  await new Promise(resolve => { img.onload = resolve })

  const scale = 240 / img.width
  canvas.width = 240
  canvas.height = img.height * scale
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height)

  for (const annName of selectedAnnotations.value) {
    const labelPath = imgPath.replace(/\.[^.]+$/, '.txt')
    const res = await apiFetch(`/api/collections/${project}/${batch}/annotations/${annName}/labels/${labelPath}`)
    const data = await res.json()
    const color = getColor(annName)
    ctx.strokeStyle = color
    ctx.lineWidth = 2
    for (const box of data.boxes) {
      const bx = (box.x - box.w / 2) * canvas.width
      const by = (box.y - box.h / 2) * canvas.height
      const bw = box.w * canvas.width
      const bh = box.h * canvas.height
      ctx.strokeRect(bx, by, bw, bh)
    }
  }
}

async function drawAll() {
  await nextTick()
  for (const img of pagedImages.value) {
    drawImage(img)
  }
}

watch([pagedImages, selectedAnnotations], drawAll, { deep: true })
onMounted(async () => {
  await loadDetail()
  await drawAll()
})

function openPreview(img) {
  window.open(`/api/collections/${project}/${batch}/images/${img}`, '_blank')
}
</script>

<style scoped>
.image-grid { display: flex; flex-wrap: wrap; gap: 12px; }
.image-card { text-align: center; }
.canvas-container { cursor: pointer; }
.canvas-container canvas { border: 1px solid #eee; border-radius: 4px; }
.image-label { font-size: 12px; color: #666; margin-top: 4px; }
</style>
