<template>
  <div v-if="detail">
    <el-breadcrumb separator=">">
      <el-breadcrumb-item :to="{ path: '/collections' }">数据采集</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: `/collections/${project}` }">{{ project }}</el-breadcrumb-item>
      <el-breadcrumb-item>{{ batch }}</el-breadcrumb-item>
    </el-breadcrumb>

    <h2 style="margin: 16px 0">{{ project }} / {{ batch }}</h2>

    <el-card style="margin-bottom: 20px">
      <template #header>采集信息</template>
      <el-descriptions :column="3" border>
        <el-descriptions-item label="工位">{{ detail.location }}</el-descriptions-item>
        <el-descriptions-item label="设备">{{ detail.device }}</el-descriptions-item>
        <el-descriptions-item label="分辨率">{{ detail.resolution }}</el-descriptions-item>
        <el-descriptions-item label="图片数">{{ detail.image_count }}</el-descriptions-item>
        <el-descriptions-item label="采集人">{{ detail.collector }}</el-descriptions-item>
        <el-descriptions-item label="备注">{{ detail.notes }}</el-descriptions-item>
      </el-descriptions>
    </el-card>

    <el-card style="margin-bottom: 20px">
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center">
          <span>图片预览</span>
          <span style="color: #999; font-size: 13px">共 {{ detail.image_count }} 张</span>
        </div>
      </template>
      <div class="image-grid">
        <div v-for="img in pagedImages" :key="img" class="image-item">
          <el-image
            :src="`/api/collections/${project}/${batch}/images/${img}`"
            fit="cover"
            lazy
            :preview-src-list="[`/api/collections/${project}/${batch}/images/${img}`]"
            style="width: 160px; height: 120px"
          />
          <div class="image-name">{{ img.split('/').pop() }}</div>
        </div>
      </div>
      <el-pagination
        v-if="detail.images.length > pageSize"
        layout="prev, pager, next"
        :total="detail.images.length"
        :page-size="pageSize"
        v-model:current-page="currentPage"
        style="margin-top: 16px; justify-content: center"
      />
    </el-card>

    <el-card>
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center">
          <span>标注版本</span>
          <el-button size="small" type="primary" @click="goToAnnotations" :disabled="!detail.annotations.length">
            查看标注
          </el-button>
        </div>
      </template>
      <el-table :data="detail.annotations" stripe>
        <el-table-column prop="name" label="版本名" />
        <el-table-column prop="type" label="类型" />
        <el-table-column prop="method" label="方法" />
        <el-table-column prop="annotated_count" label="数量" />
        <el-table-column label="状态">
          <template #default="{ row }">
            <el-tag :type="row.reviewed ? 'success' : 'warning'">{{ row.reviewed ? '已审核' : '未审核' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="create_time" label="创建时间" />
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const route = useRoute()
const router = useRouter()
const project = route.params.project
const batch = route.params.batch
const detail = ref(null)
const currentPage = ref(1)
const pageSize = 20

const pagedImages = computed(() => {
  if (!detail.value) return []
  const start = (currentPage.value - 1) * pageSize
  return detail.value.images.slice(start, start + pageSize)
})

function goToAnnotations() {
  router.push(`/collections/${project}/${batch}/annotations`)
}

onMounted(async () => {
  const res = await apiFetch(`/api/collections/${project}/${batch}`)
  detail.value = await res.json()
})
</script>

<style scoped>
.image-grid { display: flex; flex-wrap: wrap; gap: 10px; }
.image-item { text-align: center; }
.image-name { font-size: 12px; color: #666; margin-top: 4px; }
</style>
