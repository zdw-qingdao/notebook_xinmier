<template>
  <div>
    <div class="page-header">
      <h2>数据采集</h2>
      <el-button type="primary" @click="showDialog = true">+ 新建项目</el-button>
    </div>
    <el-table :data="projects" stripe @row-click="goToBatches" style="cursor: pointer">
      <el-table-column prop="project" label="项目名" />
      <el-table-column prop="type" label="描述" />
      <el-table-column prop="status" label="状态">
        <template #default="{ row }">
          <el-tag :type="row.status === '进行中' ? 'success' : 'info'">{{ row.status }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="start_date" label="开始时间" />
      <el-table-column prop="end_date" label="结束时间" />
      <el-table-column prop="batch_count" label="采集批次" />
    </el-table>

    <el-dialog v-model="showDialog" title="新建项目" width="500px">
      <el-form :model="form" label-width="80px">
        <el-form-item label="项目名"><el-input v-model="form.project" /></el-form-item>
        <el-form-item label="类型"><el-input v-model="form.type" /></el-form-item>
        <el-form-item label="设备"><el-input v-model="form.device" /></el-form-item>
        <el-form-item label="开始日期"><el-input v-model="form.start_date" type="date" /></el-form-item>
        <el-form-item label="备注"><el-input v-model="form.notes" type="textarea" /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showDialog = false">取消</el-button>
        <el-button type="primary" @click="createProject">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'

const router = useRouter()
const projects = ref([])
const showDialog = ref(false)
const form = ref({ project: '', type: '', device: '', start_date: '', notes: '' })

async function load() {
  const res = await apiFetch('/api/collections')
  projects.value = await res.json()
}

function goToBatches(row) {
  router.push(`/collections/${row.name || row.project}`)
}

async function createProject() {
  const res = await apiFetch('/api/collections', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(form.value),
  })
  if (res.ok) {
    showDialog.value = false
    form.value = { project: '', type: '', device: '', start_date: '', notes: '' }
    ElMessage.success('创建成功')
    load()
  } else {
    const err = await res.json()
    ElMessage.error(err.detail || '创建失败')
  }
}

onMounted(load)
</script>

<style scoped>
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}
</style>
