<template>
  <div>
    <el-breadcrumb separator=">">
      <el-breadcrumb-item :to="{ path: '/code' }">代码配置</el-breadcrumb-item>
      <el-breadcrumb-item>{{ isEdit ? '编辑' : '新建' }}配置</el-breadcrumb-item>
    </el-breadcrumb>

    <h2 style="margin: 16px 0">{{ isEdit ? '编辑' : '新建' }}代码配置</h2>

    <el-form :model="form" label-width="100px" style="max-width: 600px">
      <el-form-item label="配置名称">
        <el-input v-model="form.name" :disabled="isEdit" />
      </el-form-item>
      <el-divider>代码信息</el-divider>
      <el-form-item label="仓库"><el-input v-model="form.code_info.repo" /></el-form-item>
      <el-form-item label="分支"><el-input v-model="form.code_info.branch" /></el-form-item>
      <el-form-item label="Commit"><el-input v-model="form.code_info.commitid" /></el-form-item>
      <el-divider>训练参数</el-divider>
      <el-form-item label="Epochs"><el-input-number v-model="form.config.epochs" :min="1" /></el-form-item>
      <el-form-item label="Save Period"><el-input-number v-model="form.config.save_period" :min="1" /></el-form-item>
      <el-form-item label="Freeze"><el-input-number v-model="form.config.freeze" :min="0" /></el-form-item>
      <el-form-item label="Workers"><el-input-number v-model="form.config.workers" :min="0" /></el-form-item>
      <el-form-item label="ImgSz"><el-input-number v-model="form.config.imgsz" :min="32" :step="32" /></el-form-item>
      <el-form-item label="Conf"><el-input-number v-model="form.config.conf" :min="0" :max="1" :step="0.05" /></el-form-item>
      <el-form-item label="IoU"><el-input-number v-model="form.config.iou" :min="0" :max="1" :step="0.05" /></el-form-item>
      <el-form-item>
        <el-button @click="$router.push('/code')">取消</el-button>
        <el-button type="primary" @click="save">保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { reactive, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'

const route = useRoute()
const router = useRouter()
const isEdit = !!route.params.name

const form = reactive({
  name: route.params.name || '',
  code_info: { repo: '', branch: 'main', commitid: '' },
  config: { epochs: 300, save_period: 1, freeze: 0, workers: 8, imgsz: 640, conf: 0.3, iou: 0.5 },
})

async function save() {
  const url = isEdit ? `/api/code/${form.name}` : '/api/code'
  const method = isEdit ? 'PUT' : 'POST'
  const res = await apiFetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(form),
  })
  if (res.ok) {
    ElMessage.success('保存成功')
    router.push('/code')
  } else {
    const err = await res.json()
    ElMessage.error(err.detail || '保存失败')
  }
}

onMounted(async () => {
  if (isEdit) {
    const res = await apiFetch(`/api/code/${route.params.name}`)
    const data = await res.json()
    Object.assign(form.code_info, data.code_info || {})
    Object.assign(form.config, data.config || {})
  }
})
</script>
