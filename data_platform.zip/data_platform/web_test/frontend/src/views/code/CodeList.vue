<template>
  <div>
    <div class="page-header">
      <h2>代码配置</h2>
      <el-button type="primary" @click="$router.push('/code/new')">+ 新建配置</el-button>
    </div>
    <el-table :data="configs" stripe>
      <el-table-column prop="name" label="名称" />
      <el-table-column prop="repo" label="仓库" />
      <el-table-column prop="branch" label="分支" />
      <el-table-column prop="commitid" label="Commit" show-overflow-tooltip />
      <el-table-column label="操作" width="100">
        <template #default="{ row }">
          <el-button size="small" @click="$router.push(`/code/${row.name}/edit`)">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { ref, onMounted } from 'vue'

const configs = ref([])

onMounted(async () => {
  const res = await apiFetch('/api/code')
  configs.value = await res.json()
})
</script>

<style scoped>
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
</style>
