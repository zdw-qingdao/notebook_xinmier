<template>
  <div>
    <h2>评测对比</h2>

    <el-card style="margin-bottom: 16px">
      <template #header>选择模型（可多选）</template>
      <el-checkbox-group v-model="selectedModels">
        <el-checkbox v-for="m in models" :key="m.name" :value="m.name">
          {{ m.name }}
          <span v-if="m.training_log?.precision" style="color: #999; margin-left: 8px">
            P:{{ m.training_log.precision }} R:{{ m.training_log.recall }}
          </span>
        </el-checkbox>
      </el-checkbox-group>
    </el-card>

    <el-card v-if="selectedModels.length >= 2" style="margin-bottom: 16px">
      <template #header>指标对比</template>
      <el-table :data="comparisonData" border>
        <el-table-column prop="name" label="模型" />
        <el-table-column prop="precision" label="P" />
        <el-table-column prop="recall" label="R" />
      </el-table>
    </el-card>

    <el-empty v-if="selectedModels.length < 2" description="请选择至少两个模型进行对比" />
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { ref, computed, onMounted } from 'vue'

const models = ref([])
const selectedModels = ref([])

const comparisonData = computed(() => {
  return models.value
    .filter(m => selectedModels.value.includes(m.name))
    .map(m => ({
      name: m.name,
      precision: m.training_log?.precision ?? '-',
      recall: m.training_log?.recall ?? '-',
    }))
})

onMounted(async () => {
  const res = await apiFetch('/api/models')
  models.value = await res.json()
})
</script>
