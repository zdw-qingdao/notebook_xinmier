<template>
  <div>
    <div class="page-header">
      <h2>模型</h2>
    </div>
    <el-table :data="models" stripe @row-click="goToDetail" style="cursor: pointer">
      <el-table-column prop="name" label="名称" />
      <el-table-column prop="dataset_config" label="数据集" />
      <el-table-column prop="code_config" label="代码配置" />
      <el-table-column label="P">
        <template #default="{ row }">{{ row.training_log?.precision ?? '-' }}</template>
      </el-table-column>
      <el-table-column label="R">
        <template #default="{ row }">{{ row.training_log?.recall ?? '-' }}</template>
      </el-table-column>
      <el-table-column label="权重">
        <template #default="{ row }">
          <el-tag :type="row.has_weights ? 'success' : 'info'" size="small">
            {{ row.has_weights ? '有' : '无' }}
          </el-tag>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const models = ref([])

onMounted(async () => {
  const res = await apiFetch('/api/models')
  models.value = await res.json()
})

function goToDetail(row) {
  router.push(`/models/${row.name}`)
}
</script>

<style scoped>
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
</style>
