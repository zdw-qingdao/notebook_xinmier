<template>
  <div v-if="model">
    <el-breadcrumb separator=">">
      <el-breadcrumb-item :to="{ path: '/models' }">模型</el-breadcrumb-item>
      <el-breadcrumb-item>{{ model.name }}</el-breadcrumb-item>
    </el-breadcrumb>

    <h2 style="margin: 16px 0">{{ model.name }}</h2>

    <el-row :gutter="20">
      <el-col :span="12">
        <el-card style="margin-bottom: 20px">
          <template #header>基本信息</template>
          <el-descriptions :column="1" border>
            <el-descriptions-item label="代码配置">{{ model.train_config?.code_config || model.code_config || '-' }}</el-descriptions-item>
            <el-descriptions-item label="预训练模型">{{ model.train_config?.pretrained_model || model.pretrained_model || '-' }}</el-descriptions-item>
            <el-descriptions-item label="数据集">{{ model.train_config?.dataset_config || model.dataset || '-' }}</el-descriptions-item>
            <el-descriptions-item label="创建时间">{{ model.create_time || '-' }}</el-descriptions-item>
            <el-descriptions-item label="标签">{{ (model.tags || []).join(', ') || '-' }}</el-descriptions-item>
          </el-descriptions>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card style="margin-bottom: 20px">
          <template #header>训练结果</template>
          <el-descriptions :column="1" border>
            <el-descriptions-item label="Precision">{{ model.training_log?.precision ?? '-' }}</el-descriptions-item>
            <el-descriptions-item label="Recall">{{ model.training_log?.recall ?? '-' }}</el-descriptions-item>
            <el-descriptions-item label="训练时长">{{ model.training_log?.train_time || '-' }}</el-descriptions-item>
          </el-descriptions>
        </el-card>
      </el-col>
    </el-row>

    <el-card style="margin-bottom: 20px" v-if="model.weights && model.weights.length">
      <template #header>权重文件</template>
      <el-table :data="model.weights.map(w => ({ name: w }))" size="small">
        <el-table-column prop="name" label="文件名" />
        <el-table-column label="操作" width="100">
          <template #default="{ row }">
            <el-button size="small" type="primary" text
              @click="downloadFile(`/api/models/${model.name}/weights/${row.name}`)">
              下载
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card style="margin-bottom: 20px" v-if="model.config_files && model.config_files.length">
      <template #header>配置文件</template>
      <el-table :data="model.config_files.map(f => ({ name: f }))" size="small">
        <el-table-column prop="name" label="文件名" />
        <el-table-column label="操作" width="100">
          <template #default="{ row }">
            <el-button size="small" text @click="viewConfig(row.name)">查看</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card v-if="model.train_images && model.train_images.length">
      <template #header>训练图片</template>
      <div class="image-grid">
        <el-image
          v-for="img in model.train_images"
          :key="img"
          :src="`/api/models/${model.name}/train_img/${img}`"
          fit="contain"
          :preview-src-list="[`/api/models/${model.name}/train_img/${img}`]"
          style="width: 280px; height: 200px; border: 1px solid #eee; border-radius: 4px"
        />
      </div>
    </el-card>

    <el-dialog v-model="configDialog" :title="configFileName" width="600px">
      <pre style="white-space: pre-wrap; font-size: 13px">{{ configContent }}</pre>
    </el-dialog>
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const model = ref(null)
const configDialog = ref(false)
const configFileName = ref('')
const configContent = ref('')

onMounted(async () => {
  const res = await apiFetch(`/api/models/${route.params.name}`)
  model.value = await res.json()
})

async function viewConfig(filename) {
  const res = await apiFetch(`/api/models/${model.value.name}/config/${filename}`)
  const data = await res.json()
  configFileName.value = filename
  configContent.value = typeof data === 'string' ? data : (data.content || JSON.stringify(data, null, 2))
  configDialog.value = true
}

function downloadFile(url) {
  window.open(url, '_blank')
}
</script>

<style scoped>
.image-grid { display: flex; flex-wrap: wrap; gap: 12px; }
</style>
