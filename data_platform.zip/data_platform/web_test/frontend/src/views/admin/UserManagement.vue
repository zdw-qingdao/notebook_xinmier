<template>
  <div>
    <div class="page-header">
      <h2>用户管理</h2>
      <el-button type="primary" @click="showDialog = true">+ 新建用户</el-button>
    </div>
    <el-table :data="users" stripe>
      <el-table-column prop="username" label="用户名" />
      <el-table-column prop="role" label="角色">
        <template #default="{ row }">
          <el-tag :type="row.role === 'admin' ? 'danger' : ''">{{ row.role === 'admin' ? '管理员' : '普通用户' }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="200">
        <template #default="{ row }">
          <el-button size="small" @click="openResetPwd(row.username)">重置密码</el-button>
          <el-button size="small" type="danger" @click="deleteUser(row.username)"
            :disabled="row.username === currentUser.username">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog v-model="showDialog" title="新建用户" width="400px">
      <el-form :model="form" label-width="80px">
        <el-form-item label="用户名"><el-input v-model="form.username" /></el-form-item>
        <el-form-item label="密码"><el-input v-model="form.password" type="password" show-password /></el-form-item>
        <el-form-item label="角色">
          <el-select v-model="form.role">
            <el-option value="user" label="普通用户" />
            <el-option value="admin" label="管理员" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showDialog = false">取消</el-button>
        <el-button type="primary" @click="createUser">创建</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="showPwdDialog" title="重置密码" width="400px">
      <el-form label-width="80px">
        <el-form-item label="用户名"><el-input :model-value="resetUsername" disabled /></el-form-item>
        <el-form-item label="新密码"><el-input v-model="newPassword" type="password" show-password /></el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showPwdDialog = false">取消</el-button>
        <el-button type="primary" @click="resetPassword">确认</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { apiFetch, currentUser } from '../../auth'

const users = ref([])
const showDialog = ref(false)
const showPwdDialog = ref(false)
const resetUsername = ref('')
const newPassword = ref('')
const form = reactive({ username: '', password: '', role: 'user' })

async function load() {
  const res = await apiFetch('/api/auth/users')
  users.value = await res.json()
}

async function createUser() {
  const res = await apiFetch('/api/auth/users', {
    method: 'POST',
    body: JSON.stringify(form),
  })
  if (res.ok) {
    showDialog.value = false
    form.username = ''
    form.password = ''
    form.role = 'user'
    ElMessage.success('创建成功')
    load()
  } else {
    const err = await res.json()
    ElMessage.error(err.detail || '创建失败')
  }
}

async function deleteUser(username) {
  await ElMessageBox.confirm(`确认删除用户 ${username}?`, '确认')
  const res = await apiFetch(`/api/auth/users/${username}`, { method: 'DELETE' })
  if (res.ok) {
    ElMessage.success('删除成功')
    load()
  }
}

function openResetPwd(username) {
  resetUsername.value = username
  newPassword.value = ''
  showPwdDialog.value = true
}

async function resetPassword() {
  const res = await apiFetch(`/api/auth/users/${resetUsername.value}/password`, {
    method: 'PUT',
    body: JSON.stringify({ password: newPassword.value }),
  })
  if (res.ok) {
    showPwdDialog.value = false
    ElMessage.success('密码已重置')
  } else {
    const err = await res.json()
    ElMessage.error(err.detail || '重置失败')
  }
}

onMounted(load)
</script>

<style scoped>
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
</style>
