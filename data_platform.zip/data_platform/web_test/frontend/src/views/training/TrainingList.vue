<template>
  <div>
    <div class="page-header">
      <h2>训练任务</h2>
      <el-button type="primary" @click="$router.push('/training/new')">+ 新建训练</el-button>
    </div>
    <el-table :data="tasks" stripe>
      <el-table-column prop="name" label="名称" />
      <el-table-column prop="dataset_config" label="数据集" />
      <el-table-column prop="code_config" label="代码配置" />
      <el-table-column prop="pretrained_model" label="预训练模型" />
      <el-table-column label="状态">
        <template #default="{ row }">
          <el-tag :type="statusType(row.status)">{{ row.status }}</el-tag>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { ref, onMounted } from 'vue'

const tasks = ref([])

function statusType(s) {
  if (s === '已完成') return 'success'
  if (s === '训练中') return 'warning'
  return 'info'
}

onMounted(async () => {
  const res = await apiFetch('/api/training/tasks')
  tasks.value = await res.json()
})
</script>

<style scoped>
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
</style>
