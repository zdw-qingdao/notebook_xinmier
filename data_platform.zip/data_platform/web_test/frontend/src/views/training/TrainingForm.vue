<template>
  <div>
    <el-breadcrumb separator=">">
      <el-breadcrumb-item :to="{ path: '/training' }">训练任务</el-breadcrumb-item>
      <el-breadcrumb-item>新建训练</el-breadcrumb-item>
    </el-breadcrumb>

    <h2 style="margin: 16px 0">新建训练</h2>

    <el-form :model="form" label-width="120px" style="max-width: 700px">
      <el-divider>Step 1 - 选择数据集</el-divider>
      <el-form-item label="数据集">
        <el-select v-model="form.dataset_config" placeholder="选择数据集" style="width: 100%">
          <el-option v-for="ds in datasets" :key="ds.name" :value="ds.name"
            :label="`${ds.name}  (训练:${ds.train_count} 验证:${ds.val_count})`" />
        </el-select>
      </el-form-item>

      <el-divider>Step 2 - 选择代码配置</el-divider>
      <el-form-item label="代码配置">
        <el-select v-model="form.code_config" placeholder="选择代码配置" style="width: 100%">
          <el-option v-for="c in codeConfigs" :key="c.name" :value="c.name"
            :label="`${c.name}  (${c.repo} / ${c.branch})`" />
        </el-select>
      </el-form-item>

      <el-divider>Step 3 - 训练参数</el-divider>
      <el-form-item label="任务名称"><el-input v-model="form.model_name" /></el-form-item>
      <el-form-item label="预训练模型">
        <el-select v-model="form.pretrained_model" placeholder="选择或留空" clearable style="width: 100%">
          <el-option v-for="m in models" :key="m.name" :value="m.name" :label="m.name" />
        </el-select>
      </el-form-item>
      <el-form-item label="Batch"><el-input-number v-model="form.batch" :min="1" /></el-form-item>
      <el-form-item label="设备">
        <el-select v-model="form.device" multiple placeholder="GPU">
          <el-option :value="0" label="GPU 0" />
          <el-option :value="1" label="GPU 1" />
        </el-select>
      </el-form-item>

      <el-form-item>
        <el-button @click="$router.push('/training')">取消</el-button>
        <el-button type="primary" @click="startTraining">开始训练</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script setup>
import { apiFetch } from '../../auth'
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'

const router = useRouter()
const datasets = ref([])
const codeConfigs = ref([])
const models = ref([])

const form = reactive({
  model_name: '',
  dataset_config: '',
  code_config: '',
  pretrained_model: '',
  batch: 16,
  device: [0],
})

async function startTraining() {
  if (!form.model_name || !form.dataset_config || !form.code_config) {
    ElMessage.warning('请填写必要字段')
    return
  }
  const res = await apiFetch('/api/training/start', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(form),
  })
  if (res.ok) {
    ElMessage.success('训练任务已启动')
    router.push('/training')
  } else {
    const err = await res.json()
    ElMessage.error(err.detail || '启动失败')
  }
}

onMounted(async () => {
  const [dsRes, codeRes, modelRes] = await Promise.all([
    apiFetch('/api/datasets'),
    apiFetch('/api/code'),
    apiFetch('/api/models'),
  ])
  datasets.value = await dsRes.json()
  codeConfigs.value = await codeRes.json()
  models.value = await modelRes.json()
})
</script>
