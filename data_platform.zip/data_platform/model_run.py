import argparse
import json
import os
import subprocess

from utils import clone_repo


def main(config_path, inference):
    with open(config_path, "r") as f:
        config = json.load(f)

    info_path = "config/server_info.json"
    with open(info_path, "r") as f:
        info = json.load(f)

    code_config_path = os.path.join(info["code_path"], "config", config["code_config"] + ".json")
    with open(code_config_path, "r") as f:
        code_config = json.load(f)

    debug_code_folder = info.get("debug_code_folder", "")
    if debug_code_folder:
        repo_dir = debug_code_folder
    else:
        repo_dir = clone_repo(info, code_config["code_info"])

    cmd = [
        "python", os.path.join(repo_dir, "run.py"),
        "--info", json.dumps(info),
        "--config", json.dumps(config),
        "--code-config", json.dumps(code_config),
    ]
    if not inference:
        dataset_config_path = os.path.join(info["datasets_path"], config["dataset_config"] + ".json")
        cmd += [
            "--config-path", os.path.abspath(config_path),
            "--code-config-path", os.path.abspath(code_config_path),
            "--dataset-config-path", os.path.abspath(dataset_config_path),
        ]
    if inference:
        cmd.append("--inference")
    subprocess.run(cmd, check=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", type=str, required=True, help="config json file path")
    parser.add_argument("-i", "--inference", action="store_true", help="run inference instead of training")
    args = parser.parse_args()
    main(args.config, args.inference)
